package com.mycompany.prog5121poe;

import java.util.Random;

public class Message {

    private String messageID;
    private String recipientCell;
    private String messageContent;
    private String messageHash;
    private static int messageCounter = 0; // Incremented as messages are processed

    // Default Constructor
    public Message() {
    }

    // Parameterized Constructor
    public Message(String recipientCell, String messageContent) {
        this.messageID = generateMessageID();
        this.recipientCell = recipientCell;
        this.messageContent = messageContent;
        this.messageHash = createMessageHash();
    }

    // 1. Check Message ID (no more than 10 characters)
    public boolean checkMessageID() {
        return this.messageID != null && this.messageID.length() <= 10;
    }

    // Generate random 10-digit Message ID
    public String generateMessageID() {
        Random rand = new Random();
        long number = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        return String.valueOf(number);
    }

    // 2. Check Recipient Cell (starts with international code like +, max 10 chars/format)
    public boolean checkRecipientCell(String cellNumber) {
        if (cellNumber == null) return false;
        // Checks that cell starts with '+' and conforms to international length/format rules
        return cellNumber.matches("^\\+\\d{10,12}$");
    }

    public String checkRecipientCellStatus(String cellNumber) {
        if (checkRecipientCell(cellNumber)) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // 3. Message Length Check (Maximum 250 Characters)
    public String checkMessageLength(String message) {
        if (message == null) return "Please enter a message of less than 250 characters.";
        if (message.length() <= 250) {
            return "Message ready to send.";
        } else {
            int overLimit = message.length() - 250;
            return "Message exceeds 250 characters by " + overLimit + "; please reduce the size.";
        }
    }

    // 4. Create Message Hash
    // Format: First 2 numbers of ID : Message index counter : FIRST and LAST words in ALL CAPS
    public String createMessageHash() {
        if (this.messageID == null || this.messageContent == null || this.messageContent.trim().isEmpty()) {
            return "";
        }

        String idPrefix = this.messageID.substring(0, 2);
        String[] words = this.messageContent.trim().split("\\s+");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();

        return idPrefix + ":" + messageCounter + ":" + firstWord + lastWord;
    }

    // 5. SentMessage Option
    public String SentMessage(int choice) {
        switch (choice) {
            case 1:
                messageCounter++;
                return "Message successfully sent.";
            case 2:
                return "Press 0 to delete the message.";
            case 3:
                return "Message successfully stored.";
            default:
                return "Invalid choice.";
        }
    }

    // Getters and Setters
    public String getMessageID() { return messageID; }
    public String getRecipientCell() { return recipientCell; }
    public String getMessageContent() { return messageContent; }
    public String getMessageHash() { return messageHash; }
    public static int getMessageCounter() { return messageCounter; }
    public static void setMessageCounter(int count) { messageCounter = count; }
}