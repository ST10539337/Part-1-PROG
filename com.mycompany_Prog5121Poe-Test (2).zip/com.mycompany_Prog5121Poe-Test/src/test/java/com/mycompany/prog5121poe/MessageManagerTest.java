package com.mycompany.prog5121poe;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageManagerTest {

    @BeforeEach
    public void setUp() {
        // Reset arrays and counters before each test
        MessageManager.sentMessages = new String[100];
        MessageManager.disregardedMessages = new String[100];
        MessageManager.storedMessages = new String[100];
        MessageManager.messageHashes = new String[100];
        MessageManager.messageIDs = new String[100];
        MessageManager.recipients = new String[100];
        MessageManager.flags = new String[100];
        MessageManager.totalCount = 0;
        MessageManager.sentCount = 0;
        MessageManager.disregardCount = 0;
        MessageManager.storedCount = 0;

        // Populate Test Data Messages 1 to 5 from the Part 3 assignment brief
        // Message 1 (Sent)
        MessageManager.addMessageToArrays(
            "0000000001", "+27834557896",
            "Did you get the cake?", "00:1:DIDCAKE?", "Sent"
        );

        // Message 2 (Stored)
        MessageManager.addMessageToArrays(
            "0000000002", "+27838884567",
            "Where are you? You are late! I have asked you to be on time.", "00:2:WHERETIME.", "Stored"
        );

        // Message 3 (Disregard)
        MessageManager.addMessageToArrays(
            "0000000003", "+27834484567",
            "Yohoooo, I am at your gate.", "00:3:YOHOOOOGATE.", "Disregard"
        );

        // Message 4 (Sent)
        MessageManager.addMessageToArrays(
            "0838884567", "0838884567",
            "It is dinner time !", "08:4:IT!", "Sent"
        );

        // Message 5 (Stored)
        MessageManager.addMessageToArrays(
            "0000000005", "+27838884567",
            "Ok, I am leaving without you.", "00:5:OKYOU.", "Stored"
        );
    }

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        assertEquals("Did you get the cake?", MessageManager.sentMessages[0]);
        assertEquals("It is dinner time !", MessageManager.sentMessages[1]);
    }

    @Test
    public void testDisplayLongestMessage() {
        String expected = "Where are you? You are late! I have asked you to be on time.";
        assertEquals(expected, MessageManager.getLongestMessage());
    }

    @Test
    public void testSearchForMessageID() {
        String result = MessageManager.searchByMessageID("0838884567");
        assertTrue(result.contains("0838884567"));
        assertTrue(result.contains("It is dinner time !"));
    }

    @Test
    public void testSearchMessagesByRecipient() {
        String result = MessageManager.searchByRecipient("+27838884567");
        assertTrue(result.contains("Where are you? You are late! I have asked you to be on time."));
        assertTrue(result.contains("Ok, I am leaving without you."));
    }

    @Test
    public void testDeleteMessageUsingHash() {
        String response = MessageManager.deleteByHash("00:2:WHERETIME.");
        assertEquals("Message \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.", response);
    }

    @Test
    public void testDisplayReport() {
        String report = MessageManager.displaySentReport();
        assertTrue(report.contains("00:1:DIDCAKE?"));
        assertTrue(report.contains("+27834557896"));
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("08:4:IT!"));
        assertTrue(report.contains("It is dinner time !"));
    }
}