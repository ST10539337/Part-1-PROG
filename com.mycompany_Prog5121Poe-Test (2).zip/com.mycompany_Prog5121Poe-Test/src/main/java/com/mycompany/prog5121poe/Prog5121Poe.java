/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121poe;

import java.util.Scanner;

public class Prog5121Poe {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Initializing placeholder data outside the loop so it persists!
        Registration myReg = new Registration("default", "default", "default", "default", "+27000000000");
        Login myLoginSystem = new Login(myReg);
        
        boolean running = true;

        while (running) {
            System.out.println("\n--- WELCOME SYSTEM ---");
            System.out.println("1. Register a new account");
            System.out.println("2. Login to existing account");
            System.out.println("3. Exit");
            System.out.print("Choose an option (1, 2, or 3): ");
            
            String choiceStr = input.nextLine();
            int choice;
            try {
                choice = Integer.parseInt(choiceStr.trim());
            } catch (NumberFormatException e) {
                choice = -1; // Invalid choice handler
            }

            if (choice == 1) {
                System.out.println("\n--- REGISTRATION ---");
                System.out.print("Enter First Name: ");
                String fName = input.nextLine();
                
                System.out.print("Enter Last Name: ");
                String lName = input.nextLine();
                
                System.out.print("Enter Username: ");
                String uName = input.nextLine();
                
                System.out.print("Enter Password: ");
                String pWord = input.nextLine();
                
                System.out.print("Enter Cellphone Number: ");
                String cell = input.nextLine();

                // Create temporary registration object to test
                Registration tempReg = new Registration(fName, lName, uName, pWord, cell);
                String regStatus = tempReg.registerUser();
                System.out.println("\n" + regStatus);
                
                // Only save/assign the account if registration is fully successful
                if (regStatus.startsWith("Welcome")) {
                    myReg = tempReg;
                    myLoginSystem = new Login(myReg);
                } else {
                    System.out.println("Registration failed. Account was not created. Please try again.");
                }
                
            } else if (choice == 2) {
                System.out.println("\n--- LOGIN ---");
                System.out.print("Enter Username: ");
                String user = input.nextLine();
                
                System.out.print("Enter Password: ");
                String pass = input.nextLine();

                // Check if credentials match
                boolean success = myLoginSystem.loginUser(user, pass);
                System.out.println("Login Successful Status: " + success);
                
                // Fetch and display the exact text required by the rubric
                String statusMessage = myLoginSystem.returnLoginStatus(success);
                System.out.println("System Notification: " + statusMessage);
                
                // --- PART 2 & PART 3: QUICKCHAT MESSAGING INTEGRATION ---
                if (success) {
                    // Load any previously saved JSON messages into storedMessages array
                    MessageManager.loadStoredMessagesFromJSON("storedMessages.json");

                    System.out.println("\nWelcome to QuickChat.");
                    boolean chatRunning = true;

                    while (chatRunning) {
                        System.out.println("\nPlease choose an option:");
                        System.out.println("Option 1) Send Messages");
                        System.out.println("Option 2) Show recently sent messages");
                        System.out.println("Option 3) Quit");
                        System.out.println("Option 4) Stored Messages");
                        System.out.print("Enter choice (1-4): ");
                        
                        String chatChoiceStr = input.nextLine();
                        int chatChoice;
                        try {
                            chatChoice = Integer.parseInt(chatChoiceStr.trim());
                        } catch (NumberFormatException e) {
                            chatChoice = -1;
                        }

                        switch (chatChoice) {
                            case 1:
                                System.out.print("How many messages would you like to enter? ");
                                String numMsgStr = input.nextLine();
                                int numMessages;
                                try {
                                    numMessages = Integer.parseInt(numMsgStr.trim());
                                } catch (NumberFormatException e) {
                                    System.out.println("Invalid number entered. Defaulting to 1.");
                                    numMessages = 1;
                                }

                                for (int i = 0; i < numMessages; i++) {
                                    System.out.println("\n--- Entering Message " + (i + 1) + " of " + numMessages + " ---");
                                    
                                    // Keep asking until a valid cell number is entered
                                    String recipient;
                                    Message tempMsg = new Message();
                                    while (true) {
                                        System.out.print("Enter Recipient Cell Number (+27...): ");
                                        recipient = input.nextLine();
                                        
                                        String cellStatus = tempMsg.checkRecipientCellStatus(recipient);
                                        System.out.println(cellStatus);
                                        
                                        if (cellStatus.equals("Cell phone number successfully captured.")) {
                                            break; // Exit loop if valid
                                        }
                                        System.out.println("Please try entering the cell number again.\n");
                                    }

                                    System.out.print("Enter Message Content (max 250 characters): ");
                                    String content = input.nextLine();

                                    Message msg = new Message(recipient, content);

                                    // Check message length
                                    String lengthStatus = msg.checkMessageLength(content);
                                    System.out.println(lengthStatus);

                                    if (lengthStatus.equals("Message ready to send.")) {
                                        System.out.println("Choose action:");
                                        System.out.println("1) Send Message");
                                        System.out.println("2) Disregard Message");
                                        System.out.println("3) Store Message");
                                        System.out.print("Enter action choice (1-3): ");
                                        
                                        String actionStr = input.nextLine();
                                        int action;
                                        try {
                                            action = Integer.parseInt(actionStr.trim());
                                        } catch (NumberFormatException e) {
                                            action = -1;
                                        }

                                        String actionResult = msg.SentMessage(action);
                                        System.out.println(actionResult);

                                        // Populate MessageManager arrays based on action chosen
                                        if (action == 1) {
                                            MessageManager.addMessageToArrays(
                                                msg.getMessageID(), recipient, content, msg.getMessageHash(), "Sent"
                                            );
                                            System.out.println("Message ID: " + msg.getMessageID() + " | Hash: " + msg.getMessageHash() + " | Recipient: " + recipient + " | Message: " + content);
                                        } else if (action == 2) {
                                            System.out.print("Enter choice (Press 0 to delete): ");
                                            String delChoice = input.nextLine();
                                            if (delChoice.trim().equals("0")) {
                                                MessageManager.addMessageToArrays(
                                                    msg.getMessageID(), recipient, content, msg.getMessageHash(), "Disregard"
                                                );
                                                System.out.println("Message disregarded and logged.");
                                            }
                                        } else if (action == 3) {
                                            MessageManager.addMessageToArrays(
                                                msg.getMessageID(), recipient, content, msg.getMessageHash(), "Stored"
                                            );
                                            msg.storeMessage();
                                        }
                                    }
                                }
                                System.out.println("\nTotal messages sent: " + Message.getMessageCounter());
                                
 break;

                            case 2:
                                System.out.println("Coming Soon.");
                                break;

                            case 3:
                                System.out.println("Exiting QuickChat...");
                                chatRunning = false;
                                break;

                            case 4:
                                MessageManager.storedMessagesMenu(input);
                                break;

                            default:
                                System.out.println("Invalid option selected. Please choose 1, 2, 3, or 4.");
                        }
                    }
                }
                
            } else if (choice == 3) {
                System.out.println("Exiting application...");
                running = false;
            } else {
                System.out.println("Invalid option selected. Please choose 1, 2, or 3.");
            }
        }
        input.close();
    }
}