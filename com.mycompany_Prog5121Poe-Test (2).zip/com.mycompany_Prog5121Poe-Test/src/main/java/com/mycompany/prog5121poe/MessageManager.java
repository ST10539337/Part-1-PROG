package com.mycompany.prog5121poe;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MessageManager {

    // Parallel arrays to store message details
    public static String[] sentMessages = new String[100];
    public static String[] disregardedMessages = new String[100];
    public static String[] storedMessages = new String[100];
    public static String[] messageHashes = new String[100];
    public static String[] messageIDs = new String[100];

    // Parallel arrays to track Recipients and Flags for easy lookup
    public static String[] recipients = new String[100];
    public static String[] flags = new String[100];

    public static int totalCount = 0;
    public static int sentCount = 0;
    public static int disregardCount = 0;
    public static int storedCount = 0;

    // Populates the arrays dynamically as messages are created or loaded
    public static void addMessageToArrays(String id, String recipient, String message, String hash, String flag) {
        messageIDs[totalCount] = id;
        recipients[totalCount] = recipient;
        messageHashes[totalCount] = hash;
        flags[totalCount] = flag;

        if (flag.equalsIgnoreCase("Sent")) {
            sentMessages[sentCount++] = message;
        } else if (flag.equalsIgnoreCase("Disregard")) {
            disregardedMessages[disregardCount++] = message;
        } else if (flag.equalsIgnoreCase("Stored")) {
            storedMessages[storedCount++] = message;
        }
        totalCount++;
    }

    // Reads JSON file from Part 2 into the storedMessages array
    public static void loadStoredMessagesFromJSON(String filePath) {
        try {
            String content = new String(Files.readAllBytes(Paths.get(filePath)));
            Pattern pattern = Pattern.compile(
                "\"MessageID\"\\s*:\\s*\"([^\"]*)\".*?" +
                "\"Recipient\"\\s*:\\s*\"([^\"]*)\".*?" +
                "\"Message\"\\s*:\\s*\"([^\"]*)\".*?" +
                "\"MessageHash\"\\s*:\\s*\"([^\"]*)\"",
                Pattern.DOTALL
            );
            Matcher matcher = pattern.matcher(content);
            while (matcher.find()) {
                addMessageToArrays(
                    matcher.group(1),
                    matcher.group(2),
                    matcher.group(3),
                    matcher.group(4),
                    "Stored"
                );
            }
        } catch (Exception e) {
            System.out.println("Note: No existing JSON file loaded (" + e.getMessage() + ")");
        }
    }

    // Submenu for Part 3 Requirement 2
    public static void storedMessagesMenu(Scanner input) {
        System.out.println("\n--- Stored Messages & Reports Menu ---");
        System.out.println("a. Display sender and recipient of all messages");
        System.out.println("b. Display the longest message");
        System.out.println("c. Search for a Message ID");
        System.out.println("d. Search all messages for a particular recipient");
        System.out.println("e. Delete a message using Message Hash");
        System.out.println("f. Display full Sent Messages Report");
        System.out.print("Choose an option (a-f): ");

        String choice = input.nextLine().trim().toLowerCase();

        switch (choice) {
            case "a":
                System.out.println("\n" + displaySendersAndRecipients());
                break;
            case "b":
                System.out.println("\nLongest Message: " + getLongestMessage());
                break;
            case "c":
                System.out.print("Enter Message ID: ");
                String searchId = input.nextLine().trim();
                System.out.println("\n" + searchByMessageID(searchId));
                break;
            case "d":
                System.out.print("Enter Recipient Number: ");
                String searchRec = input.nextLine().trim();
                System.out.println("\n" + searchByRecipient(searchRec));
                break;
            case "e":
                System.out.print("Enter Message Hash to delete: ");
                String delHash = input.nextLine().trim();
                System.out.println("\n" + deleteByHash(delHash));
                break;
            case "f":
                System.out.println("\n" + displaySentReport());
                break;
            default:
                System.out.println("Invalid option selected.");
        }
    }

    // 2a. Display sender and recipient of all messages
    public static String displaySendersAndRecipients() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < totalCount; i++) {
            if (messageIDs[i] != null) {
                sb.append("Sender: Developer | Recipient: ").append(recipients[i]).append("\n");
            }
        }
        if (sb.length() == 0) return "No messages found.";
        return sb.toString().trim();
    }

    // 2b. Display the longest message
    public static String getLongestMessage() {
        String longest = "";
        for (int i = 0; i < sentCount; i++) {
            if (sentMessages[i] != null && sentMessages[i].length() > longest.length()) {
                longest = sentMessages[i];
            }
        }
        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i] != null && storedMessages[i].length() > longest.length()) {
                longest = storedMessages[i];
            }
        }
        return longest;
    }

    // 2c. Search for a Message ID and display corresponding recipient and message
    public static String searchByMessageID(String searchID) {
        for (int i = 0; i < totalCount; i++) {
            if (messageIDs[i] != null && messageIDs[i].equals(searchID)) {
                String msgContent = getMessageByIndex(i);
                return "Recipient: " + recipients[i] + "\nMessage: " + msgContent;
            }
        }
        return "Message ID not found.";
    }

    // 2d. Search all messages sent or stored for a particular recipient
    public static String searchByRecipient(String recipientNumber) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < totalCount; i++) {
            if (recipients[i] != null && recipients[i].equals(recipientNumber)) {
                if (flags[i].equalsIgnoreCase("Sent") || flags[i].equalsIgnoreCase("Stored")) {
                    sb.append(getMessageByIndex(i)).append("\n");
                }
            }
        }
        if (sb.length() == 0) return "No messages found for recipient.";
        return sb.toString().trim();
    }

    // 2e. Delete a message using the message hash
    public static String deleteByHash(String hash) {
        for (int i = 0; i < totalCount; i++) {
            if (messageHashes[i] != null && messageHashes[i].equalsIgnoreCase(hash)) {
                String deletedMsg = getMessageByIndex(i);

                removeFromFlagArray(deletedMsg, flags[i]);

                messageIDs[i] = null;
                recipients[i] = null;
                messageHashes[i] = null;
                flags[i] = null;

                return "Message \"" + deletedMsg + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    // 2f. Display report listing full details of all sent messages
    public static String displaySentReport() {
        StringBuilder sb = new StringBuilder("=== SENT MESSAGES REPORT ===\n");
        for (int i = 0; i < totalCount; i++) {
            if (flags[i] != null && flags[i].equalsIgnoreCase("Sent")) {
                sb.append("Message Hash: ").append(messageHashes[i]).append("\n")
                  .append("Recipient: ").append(recipients[i]).append("\n")
                  .append("Message: ").append(getMessageByIndex(i)).append("\n")
                  .append("-----------------------------\n");
            }
        }
        return sb.toString().trim();
    }

    // Helper method to get message text matching master index i
    private static String getMessageByIndex(int masterIndex) {
        String targetFlag = flags[masterIndex];
        int flagOccurrence = 0;
        for (int j = 0; j < masterIndex; j++) {
            if (flags[j] != null && flags[j].equalsIgnoreCase(targetFlag)) {
                flagOccurrence++;
            }
        }
        if (targetFlag.equalsIgnoreCase("Sent")) return sentMessages[flagOccurrence];
        if (targetFlag.equalsIgnoreCase("Stored")) return storedMessages[flagOccurrence];
        return disregardedMessages[flagOccurrence];
    }

    // Helper method to remove deleted message from its specific array
    private static void removeFromFlagArray(String msg, String flag) {
        if (flag.equalsIgnoreCase("Sent")) {
            for (int i = 0; i < sentCount; i++) {
                if (msg.equals(sentMessages[i])) sentMessages[i] = null;
            }
        } else if (flag.equalsIgnoreCase("Stored")) {
            for (int i = 0; i < storedCount; i++) {
                if (msg.equals(storedMessages[i])) storedMessages[i] = null;
            }
        }
    }
}